<?php

use App\Http\Controllers\AcquisitionsController;
use App\Http\Controllers\DevisController;
use App\Http\Controllers\InterventionsController;
use App\Http\Controllers\LivraisonsController;
use App\Http\Controllers\StocksController;
use App\Http\Controllers\ServicesController;
use App\Http\Controllers\DirectionsController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Route::get('/', function () {
    return view('auth.connexion');
});
 */
Route::get('/', [UserController::class, 'login']); 
Route::get('register', [UserController::class, 'register']);
Route::post('check', [UserController::class, 'check'])->name('check');
Route::post('store', [UserController::class, 'store'])->name('store');
Route::get('forgot', [UserController::class, 'forgot']);
Route::put('/resetpassword', [UserController::class, 'resetpassword']);
Route::put('/reset', [UserController::class, 'reset']);

Route::group(['middleware'=> ['logged']], function(){

    Route::get('/index', [UserController::class, 'index']);
    Route::get('/logout', [UserController::class, 'logout']);
    Route::get('/profile', [UserController::class, 'profile']);
    Route::put('changeprofile', [UserController::class, 'changeprofile']);

    Route::get('/stocks', [StocksController::class, 'index']);

    Route::get('/stocks/edit/{stock}', [StocksController::class, 'edit']);
    Route::get('/stocks/rentree/{stock}', [StocksController::class, 'rentree']);
    Route::get('/stocks/sortie/{stock}', [StocksController::class, 'sortie']);
    Route::put('/stocks/retrait/{stock}', [StocksController::class, 'soustraction']);
    Route::put('/stocks/ajout/{stock}', [StocksController::class, 'addition']);

    Route::get('stocks/newmateriel', [StocksController::class, 'create']);
    Route::post('stocks/store', [StocksController::class, 'store'])->name('stocks/store');

    Route::get('/acquisition', [AcquisitionsController::class, 'index']);
    Route::get('/acquisition/newacquis', [AcquisitionsController::class, 'create']);
    Route::post('/acquisition/addacquisition', [AcquisitionsController::class, 'store']);
    Route::get('getServices', [ServicesController::class, 'getServices'])->name('getServices');
    Route::get('/acquisition/fiche/{acquisition}', [AcquisitionsController::class, 'show']);
    Route::get('/acquisition/edit/{acquisition}', [AcquisitionsController::class, 'edit']);
    Route::put('/acquisition/update/{acquisition}', [AcquisitionsController::class, 'update']);
    Route::delete('/acquisition/delete/{acquisition}', [AcquisitionsController::class, 'destroy']);
    Route::put('/acquisition/sihvalide/{acquisition}', [AcquisitionsController::class, 'sihvalide']);
    Route::put('/acquisition/dirvalide/{acquisition}', [AcquisitionsController::class, 'dirvalide']);
    Route::put('/acquisition/dsivalide/{acquisition}', [AcquisitionsController::class, 'dsivalide']);
    Route::put('/acquisition/change_status/{acquisition}', [AcquisitionsController::class, 'change_status']);
    Route::get('/generate-pdf/{acquisition}', [AcquisitionsController::class, 'generatePDF']);

 
    Route::get('/intervention', [InterventionsController::class, 'index']);
    Route::get('/intervention/newintervention', [InterventionsController::class, 'create']);
    Route::post('/intervention/addintervention', [InterventionsController::class, 'store']);
    Route::get('/intervention/fiche/{intervention}', [InterventionsController::class, 'show']);
    Route::get('/intervention/edit/{intervention}', [InterventionsController::class, 'edit']);
    Route::get('/intervention/devis/{intervention}', [DevisController::class, 'create']);
    Route::get('/intervention/download/{devi}', [DevisController::class, 'download']);
    Route::post('/intervention/adddevis', [DevisController::class, 'store'])->name('adddevis');
    Route::delete('/intervention/delete/{intervention}', [InterventionsController::class, 'destroy']);
    Route::put('/intervention/editfiche/{intervention}', [InterventionsController::class, 'editfiche']);
    Route::put('/intervention/dirvalide/{intervention}', [InterventionsController::class, 'dirvalide']);
    Route::put('/intervention/sihvalide/{intervention}', [InterventionsController::class, 'sihvalide']);
    Route::put('/intervention/commentaire/{intervention}', [InterventionsController::class, 'commentaire']);
    Route::put('/intervention/dinvalide/{intervention}', [InterventionsController::class, 'dinvalide']);


    Route::get('/livraison', [LivraisonsController::class, 'index']);
    Route::get('/livraison/newlivraison', [LivraisonsController::class, 'create']);
    Route::put('/livraison/addlivraison', [LivraisonsController::class, 'store']);
    Route::get('/livraison/show/{livraison}', [LivraisonsController::class, 'show']);
    Route::get('/generate-livraison/{livraison}', [LivraisonsController::class, 'generatePDF']);
    

    Route::get('/admin', [UserController::class, 'admin']);
    Route::get('/admin/newdir', [DirectionsController::class, 'create']);
    Route::get('/admin/newservice', [ServicesController::class, 'create']);
    Route::get('/admin/newuser', [UserController::class, 'create']);
    Route::get('/admin/showuser', [UserController::class, 'list']);
    Route::get('/admin/useredit/{user}', [UserController::class, 'edit']);
    Route::delete('/admin/userdelete/{user}', [UserController::class, 'destroy']);
    Route::put('/admin/updateuser/{user}', [UserController::class, 'update']);

    Route::get('/admin/showdirections', [DirectionsController::class, 'index']);
    Route::get('/admin/dirshow/{direction}', [DirectionsController::class, 'show']);
    Route::get('/admin/diredit/{direction}', [DirectionsController::class, 'edit']);
    Route::delete('/admin/dirdelete/{direction}', [DirectionsController::class, 'destroy']);
    Route::put('/admin/updatedir/{direction}', [DirectionsController::class, 'update']);

    Route::get('/admin/showservices', [ServicesController::class, 'index']);
    Route::get('/admin/serviceedit/{service}', [ServicesController::class, 'edit']);
    Route::delete('/admin/servicedelete/{service}', [ServicesController::class, 'destroy']);
    Route::put('/admin/updateservice/{service}', [ServicesController::class, 'update']);

     

    Route::post('/admin/addir', [DirectionsController::class, 'store']);
    Route::post('/admin/addservice', [ServicesController::class, 'store']);
    Route::post('/admin/adduser', [UserController::class, 'store']);

});

