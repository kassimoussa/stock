
<h3> Mission approuvé </h3>

<p>La mission que vous avez soumis dans le Gestionnaire des  missions le  {{ date('d/m/Y à H:i:s', strtotime($mission->date_submit))}} viens d'êtres approuvé. <br>
    Pour voir la mission cliquer sur la rubirique <a href="http://workflow.test/approuved">Missions Approuvées</a> . </p>
