
<h3> Restitution de mot de passe </h3>

<p>Le code secret est :  {{ $rand}} . <br>
    Vous pouvez réinitialiser votre mot de passe en cliquant <a href="http://stock.test/reset">ici</a> . </p>
