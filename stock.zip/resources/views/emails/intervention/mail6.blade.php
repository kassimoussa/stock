
<h3> Le chef de DIN a validé la fiche d'intervention n°{{ $fiche }}  . </h3>

<h4> Pour voir et valider la fiche cliquer <a href="http://stock.test/intervention/fiche/{{ $fiche }}">ici.</a></h4>