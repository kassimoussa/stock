
<h3> Une nouvelle fiche d'intervention a été soumit dans le Gestionnaire des Stock  par {{ $nom_demandeur }} du service {{ $service_demandeur }} . </h3>

<h4> Pour voir et valider la fiche cliquer sur la rubirique Intervention</h4>