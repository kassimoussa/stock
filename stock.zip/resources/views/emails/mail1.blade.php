
<h3> Une nouvelle fiche d'acquisition a été soumit dans le Gestionnaire des Stock  par la {{ $direction }} . </h3>

<h4> Il s'agit d'une acquisition de {{ $materiel }} pour {{ $nom }} du service {{ $service }}.  </h4>

<h4> Pour voir et approuver la fiche cliquer sur la rubirique Acquisition</h4>