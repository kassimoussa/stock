
<h3> Une nouvelle fiche d'acquisition soumit dans le Gestionnaire des Stock </h3>

<p> La fiche a été soumise le {{ date('d/m/Y à H:i:s', strtotime($date_submit))}} viens d'étre valider par le directeur de la  {{ $dirdemandeur }} . <br>
    Pour voir et approuver la fiche cliquer sur la rubrique Acquisition puis sur voir la fiche. </p>
