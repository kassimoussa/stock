
<h3> Fiche d'Acquisition validé </h3>

<p>La fiche d'acquisition n°{{ $ficheId  }} que vous avez soumis dans le Gestionnaire des  Stock le  {{ date('d/m/Y à H:i:s', strtotime($date_submit))}} viens d'êtres approuvé. <br>
    Pour voir et imprimer   <a href="http://stock.test/acquisition/fiche/{{ $ficheId }}">la fiche </a> . </p>
