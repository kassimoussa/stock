<?php

namespace App\Http\Controllers;

use App\Models\Direction;
use Illuminate\Http\Request;
use App\Models\Intervention;
use App\Models\Service;
use App\Models\User;
use PDF;
use Mail;
use App\Mail\NotifInter1;
use App\Mail\NotifInter2;
use App\Mail\NotifInter3;
use App\Mail\NotifInter4;
use App\Mail\NotifInter5;
use App\Mail\NotifInter6;
use App\Mail\NotifInter7;
use App\Models\Devis;

class InterventionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $devis = Devis::all();

        if (session('userLevel') == '1') {
            $interventions = Intervention::orderBy('id', 'desc')->paginate(5);
            return view('1.intervention.index', compact('interventions'));
        } 
        elseif (session('userLevel') == '2') {
            if (session('dir') == 'DSI' || session('service') == 'IT HelpDesk' ) {
                $interventions = Intervention::orderBy('id', 'desc')->paginate(10);
                return view('2.sih.intervention.index', compact('interventions'));
            } else {
                $interventions = Intervention::Where(function ($query) {
                    $query->where('status_sih', 'approuve')
                    ->where('dir_demandeur', session('dir'))
                    ->where('service_demandeur', session('service'));
                })->orderBy('id', 'desc')->paginate(10);
                return view('2.intervention.index', compact('interventions','devis'));
            } 
        } 
        elseif (session('userLevel') == '3') {
            $interventions = Intervention::Where(function ($query) {
                $query->where('status_dir', 'approuve');
            })->orderBy('id', 'desc')->paginate(5);
            return view('3.intervention.index', compact('interventions'));
        } 
        elseif (session('userLevel') == '4') {
            $interventions = Intervention::Where(function ($query) {
                $query->where('dir_demandeur', session('dir'));
            })->orderBy('id', 'desc')->paginate(5);
            return view('4.intervention.index', compact('interventions'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $services = Service::all();
        $directions = Direction::all();
        if (session('userLevel') == '1') {
            return view('1.intervention.newintervention', compact('services', 'directions'));
        } elseif (session('userLevel') == '2') {
            if (session('dir') == 'DSI') {
                return view('2.sih.intervention.newintervention', compact('services','directions'));
            } else {
                return view('2.intervention.newintervention', compact('services','directions'));
            } 
            
        } elseif (session('userLevel') == '3') {
            return view('3.intervention.newintervention', compact('services'));
        } elseif (session('userLevel') == '4') {
            return view('4.intervention.newintervention', compact('services'));
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /* $request->validate([
            "nom_demandeur" => 'required',
            "nom_intervenant" => 'required',
            "service_demandeur" => 'required',
            "diagnostique" => 'required',
            "materiel" => 'required',
            "model" => 'required',
            "commentaire" => 'required',
            "ref_patrimoine" => 'required',
        ]); */

        $intervention = new Intervention();
        $intervention->nom_demandeur = $request->nom_demandeur;
        $intervention->nom_intervenant = $request->nom_intervenant;
        $intervention->dir_demandeur = $request->dir_demandeur;
        $intervention->service_demandeur = $request->service_demandeur;
        $intervention->diagnostique = $request->diagnostique;
        $intervention->ref_patrimoine = $request->ref_patrimoine;
        $intervention->materiel = $request->materiel;
        $intervention->model = $request->model;
        $intervention->date_acquisition = $request->date_acquisition;
        $intervention->date_intervention = $request->date_intervention;
        $intervention->submitbyID = session('Loggeduser');
        $query = $intervention->save();

        $user = User::where('level', '2')->where('direction', 'DSI')
                    ->where('service', 'IT HelpDesk')->first();

        $nom = $request->input('nom_demandeur');
        $service = $request->input('service_demandeur');
        $to_name = $user->name;
        $to_email = $user->email;

        if ($query) {
            Mail::to($to_email, $to_name)
                ->later(now()->addSeconds(1), new NotifInter1($nom, $service));
            return back()->with('success', 'Ajout réussi !');
        } else {
            return back()->with('fail', 'Echec de l\'ajout ');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Intervention $intervention)
    {
        $devis = Devis::where('fiche_intervention', $intervention->id)->get();
        if (session('userLevel') == '1') {
            return view('1.intervention.show', compact('intervention'));
        } elseif (session('userLevel') == '2') {
            if (session('dir') == 'DSI') {
                return view('2.sih.intervention.show', compact('intervention', 'devis'));
            } else {
                return view('2.intervention.show', compact('intervention', 'devis'));
            }
        } elseif (session('userLevel') == '3') {
            return view('3.intervention.show', compact('intervention', 'devis'));
        } elseif (session('userLevel') == '4') {
            return view('4.intervention.show', compact('intervention', 'devis'));
        }
    }

    public function dirvalide(Request $request, Intervention $intervention)
    {
        $commentaire =  $request->commentaire;
        $date =  $request->date_dir;
        $status =  $request->status_dir;
        /* if($status == 'approuve'){
            $intervention->update(['suggestion' => $suggestion, 'date_ser_approbation' => $date, 'status_service' => $status ]);
        } */
        $query = $intervention->update(['commentaire' => $commentaire, 'date_dir' => $date, 'status_dir' => $status]);

        if ($query) {
            if ($status == 'approuve') {
                $user = User::where('level', '3')->first();
                $nom = $intervention->nom_demandeur;
                $service = $intervention->service_demandeur;
                $dir = $intervention->dir_demandeur;
                $fiche = $intervention->id;
                $to_name = $user->name;
                $to_email = $user->email;

                Mail::to($to_email, $to_name)
                    ->later(now()->addSeconds(1), new NotifInter2($nom, $service, $dir, $fiche));
            } elseif ($status == 'attente' || $status == 'rejete') {
                $user = User::where('level', '2')->where('direction', 'DSI')
                ->where('service', 'IT HelpDesk')->first();
                $nom = $intervention->nom_demandeur;
                $service = $intervention->service_demandeur;
                $dir = $intervention->dir_demandeur;
                $fiche = $intervention->id;
                $to_name = $user->name;
                $to_email = $user->email;

                Mail::to($to_email, $to_name)
                    ->later(now()->addSeconds(1), new NotifInter3($nom, $service, $dir, $fiche, $status));
            }
            return back()->with('success', 'Ajout effectué');
        }
    }

    public function sihvalide(Request $request, Intervention $intervention)
    {
        $suggestion =  $request->suggestion;
        $date =  $request->date_sih;
        $status =  $request->status_sih;
        /* if($status == 'approuve'){
            $intervention->update(['suggestion' => $suggestion, 'date_ser_approbation' => $date, 'status_service' => $status ]);
        } */
        $query = $intervention->update(['suggestion' => $suggestion, 'date_sih' => $date, 'status_sih' => $status]);

        if ($query) {
            if ($status == 'approuve') {
                
                $nom = $intervention->nom_demandeur;
                $service = $intervention->service_demandeur;
                $dir = $intervention->dir_demandeur;
                $fiche = $intervention->id;
                $user = User::where('level', '2')->where('direction',  $dir)
                    ->where('service', $service)->first();
                    $to_name = $user->name;
                $to_email = $user->email;

                Mail::to($to_email, $to_name)
                    ->later(now()->addSeconds(1), new NotifInter4($nom, $service, $dir, $fiche));
            
                } elseif ($status == 'attente' || $status == 'rejete') {
                $user = $user = User::where('level', '1')->where('id', $intervention->submitbyID)->first();
                $nom = $intervention->nom_demandeur;
                $service = $intervention->service_demandeur;
                $dir = $intervention->dir_demandeur;
                $fiche = $intervention->id;
                $to_name = $user->name;
                $to_email = $user->email;

                Mail::to($to_email, $to_name)
                    ->later(now()->addSeconds(1), new NotifInter5($nom, $service, $dir, $fiche, $status));
            }
            return back()->with('success', 'Modification effectué');
        }
    }

    public function dinvalide(Request $request, Intervention $intervention)
    {
        $avis =  $request->avis;
        $date =  $request->date_din;
        $status =  $request->status_din;
        
        $query = $intervention->update(['avis' => $avis, 'date_din' => $date, 'status_din' => $status]);

        if ($query) {
            if ($status == 'approuve') {
                
                $nom = $intervention->nom_demandeur;
                $service = $intervention->service_demandeur;
                $dir = $intervention->dir_demandeur;
                $fiche = $intervention->id;
                $user = User::where('level', '2')->where('direction',  $dir)
                    ->where('service', $service)->first();
                $to_name = $user->name;
                $to_email = $user->email;

                Mail::to($to_email, $to_name)
                    ->later(now()->addSeconds(1), new NotifInter4($nom, $service, $dir, $fiche));
            } elseif ($status == 'attente' || $status == 'rejete') {
                
                $nom = $intervention->nom_demandeur;
                $service = $intervention->service_demandeur;
                $dir = $intervention->dir_demandeur;
                $fiche = $intervention->id;
                $user = User::where('level', '2')->where('direction',  $dir)
                    ->where('service', $service)->first();
                $to_name = $user->name;
                $to_email = $user->email;

                Mail::to($to_email, $to_name)
                    ->later(now()->addSeconds(1), new NotifInter5($nom, $service, $dir, $fiche, $status));
            }
            return back()->with('success', 'Modification effectué');
        }
    }

    public function avis(Request $request, Intervention $intervention)
    {
        $avis =  $request->avis;
        $date =  $request->date_div;
        $status =  $request->status_div;
        $query = $intervention->update(['avis' => $avis, 'date_div' => $date, 'status_div' => $status]);

        if ($query) {
            /* if ($status == 'approuve') {
                $user = User::where('id', $intervention->submitbyID)->first();
                $user2 = User::where('direction', $intervention->dir_demandeur)
                ->where('level', '4')->first();
                $user3 = User::where('level', '3')->first();
                $nom = $intervention->nom_demandeur;
                $service = $intervention->service_demandeur;
                $dir = $intervention->dir_demandeur;
                $fiche = $intervention->id;
                $to_email = [$user->email, $user2->email, $user3->email];

                Mail::to($to_email)
                    ->later(now()->addSeconds(1), new NotifInter6($nom, $service, $dir, $fiche));
            } elseif ($status == 'attente' || $status == 'rejete') {
                $user = User::where('direction', $intervention->dir_demandeur)
                    ->where('level', '3')->first();
                $nom = $intervention->nom_demandeur;
                $service = $intervention->service_demandeur;
                $dir = $intervention->dir_demandeur;
                $fiche = $intervention->id;
                $to_name = $user->name;
                $to_email = $user->email;

                Mail::to($to_email, $to_name)
                    ->later(now()->addSeconds(1), new NotifInter7($nom, $service, $dir, $fiche, $status));
            } */
            return back()->with('success', 'Modification effectué');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Intervention $intervention)
    {
        $services = Service::where('direction', 'DSI')->get();
        $directions = Direction::all();
        if (session('userLevel') == '1') {
            return view('1.intervention.edit', compact('intervention', 'directions', 'services'));
        } elseif (session('userLevel') == '2') {
            if (session('dir') == 'DSI') {
                return view('2.sih.intervention.edit', compact('intervention', 'directions', 'services'));
            } else {
                return view('2.intervention.edit', compact('intervention', 'directions', 'services'));
            }
           
        } elseif (session('userLevel') == '3') {
            return view('3.intervention.edit', compact('intervention'));
        } elseif (session('userLevel') == '4') {
            return view('4.intervention.edit', compact('intervention'));
        }
    }

    public function editfiche(Request $request, Intervention $intervention)
    {
        $intervention->update($request->all());

        return back()->with('success', 'Modification réussie');
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Intervention $intervention)
    {
        $intervention->delete();

        return back()->with('success', 'fiche supprimé');
    }
}
