<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Acquisition;
use App\Models\Direction;
use App\Models\Service;
use App\Models\User;
use PDF;
use Mail;
use App\Mail\Notif1;
use App\Mail\Notif2;
use App\Mail\Notif3;

class AcquisitionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (session('userLevel') == '1') {
            $acquisitions = Acquisition::orderBy('id', 'desc')->paginate(5);
            return view('1.acquisition.index', compact('acquisitions'));
        } 
        elseif (session('userLevel') == '2') {
            $acquisitions = Acquisition::Where(function ($query) {
                $query->where('status_dir', 'approuve');
            })->orderBy('updated_at', 'desc')->paginate(10);
            return view('2.sih.acquisition.index', compact('acquisitions'));
        } 
        elseif (session('userLevel') == '3') {
            $acquisitions = Acquisition::Where(function ($query) {
                $query->where('status_sih', 'approuve');
            })->orderBy('id', 'desc')->paginate(10);
            return view('3.acquisition.index', compact('acquisitions'));
        } 
        elseif (session('userLevel') == '4') {
            if(session('dir') == 'DSI'){
                $acquisitions = Acquisition::Where(function ($query) {
                    $query->where('status_sih', 'approuve');
                })->orderBy('id', 'desc')->paginate(10);
                return view('4.dsi.acquisition.index', compact('acquisitions')); 
            }else {
               $acquisitions = Acquisition::Where(function ($query) {
                $query->where('dir_demandeur', session('dir'));
            })->orderBy('id', 'desc')->paginate(10);
            return view('4.acquisition.index', compact('acquisitions')); 
            }
            
        }
    }

    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $directions = Direction::all();
        $services = Service::where('direction', session('dir'))->get();
        if(session('dir') == 'DSI'){
            return view('4.dsi.acquisition.newacquis', compact('services')); 
        }else {
            return view('4.acquisition.newacquis', compact('services')); 
        }
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "nom_demandeur" => 'required',
            "service_demandeur" => 'required',
            "nom_mat" => 'required',
            "marque_mat" => 'required',
        ]);

        $stadsi = null;
        $datedsi = null;
        $datesih = null;
        if (session('dir') == "DSI") {
            $stadsi = "approuve";
            $datedsi = $request->date_submit;
            $datesih = $request->date_submit;
        } else {
            $stadsi = null;
            $datedsi = null;
            $datesih = null;
        }

        $acquisition = new Acquisition();
        $acquisition->nom_demandeur = $request->nom_demandeur;
        $acquisition->dir_demandeur = session('dir');
        $acquisition->service_demandeur = $request->service_demandeur;
        $acquisition->nom_mat = $request->nom_mat;
        $acquisition->description_mat = $request->description_mat;
        $acquisition->marque_mat = $request->marque_mat;
        $acquisition->processeur_mat = $request->processeur_mat;
        $acquisition->ram_mat = $request->ram_mat;
        $acquisition->stockage_mat = $request->stockage_mat;
        $acquisition->os_mat = $request->os_mat;
        $acquisition->date_submit = $request->date_submit;
        $acquisition->date_dir = $request->date_submit;
        $acquisition->date_sih= $datedsi;
        $acquisition->date_dsi = $datedsi;
        $acquisition->status_dir = "approuve";
        $acquisition->status_dsi = $stadsi;
        $acquisition->status_sih = $stadsi;
        $acquisition->submitbyID = session('Loggeduser');
        $query = $acquisition->save();

        $user = User::where('level', '2')->where('direction', 'DSI')
                ->where('service', 'IT HelpDesk')->first();

        $submitby = session('username');
        $nom = $request->nom_demandeur;
        $service = $request->service_demandeur;
        $direction = session('dir');
        $materiel = $request->materiel;
        $to_name = $user->name;
        $to_email = $user->email;
        if ($query) {
            Mail::to($to_email, $to_name)
                ->later(now()->addSeconds(1), new Notif1($nom, $service, $direction, $submitby, $materiel));
            return back()->with('success', 'Ajout réussi');
        } else {
            return back()->with('fail', 'Echec de l\'ajout ');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Acquisition $acquisition)
    {
        $user = User::where('id', session('Loggeduser'))->first();
        if (session('userLevel') == '1') {
            return view('1.acquisition.show', compact('acquisition', 'user'));
        } elseif (session('userLevel') == '2') {
            return view('2.acquisition.show', compact('acquisition', 'user'));
        } elseif (session('userLevel') == '3') {
            return view('3.acquisition.show', compact('acquisition', 'user'));
        }elseif (session('userLevel') == '4') {
            if(session('dir') == 'DSI'){
                return view('4.dsi.acquisition.show', compact('acquisition')); 
            }else {
                return view('4.acquisition.show', compact('acquisition', 'user'));
            }
        }
        
    }

    public function generatePDF(Acquisition $acquisition)
    {
        //PDF::setOptions(['defaultFont' => 'sans-serif']);
        $pdf = PDF::loadView('pdf.ficheacq', compact('acquisition'));

        return $pdf->download('fiche.pdf');
        /* return view('fiches', compact('acquisition')); */
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Acquisition $acquisition)
    {
        $directions = Direction::all();
        return view('1.acquisition.edit', compact('acquisition', 'directions'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Acquisition $acquisition)
    {
        $acquisition->update($request->all());

        return back()->with('success', 'Modification réussie');
    }


    public function sihvalide(Request $request, Acquisition $acquisition)
    {
        $date =  $request->date_sih;
        $status =  $request->status_sih;
        $dirdemandeur = $acquisition->dir_demandeur;
        $date_submit = $acquisition->date_submit;
        $acquisition->update(['status_sih' => $status, 'date_sih' => $date]);

        $user = User::where('level', '4')->where('direction', 'DSI')->first();

        
        $to_email = $user->email;
        /* Mail::to($to_email)
            ->later(now()->addSeconds(1), new Notif2($dirdemandeur, $date_submit)); */

        return redirect('/acquisition')->with('success', 'Action éffectue');
        /* return back()->with('success', 'Modification réussie'); */
    }

    public function dsivalide(Request $request, Acquisition $acquisition)
    {
        $date =  $request->date_dsi;
        $status =  $request->status_dsi;
        $dirdemandeur = $acquisition->dir_demandeur;
        $date_submit = $acquisition->date_submit;
        $acquisition->update(['status_dsi' => $status, 'date_dsi' => $date]);

        $user = User::where('level', '4')->where('direction', $dirdemandeur)->first();

        
        $to_email = $user->email;
        /* Mail::to($to_email)
            ->later(now()->addSeconds(1), new Notif2($dirdemandeur, $date_submit)); */

        return redirect('/acquisition')->with('success', 'Action éffectue');
        /* return back()->with('success', 'Modification réussie'); */
    }

    public function change_status(Request $request, Acquisition $acquisition)
    {
        if($acquisition->status == 0 ){
            $acquisition->update(['status' => '1']);
        }else{
           $acquisition->update(['status' => '0']); 
        }
        

        return redirect('/acquisition')->with('success', 'Status changé');
        /* return back()->with('success', 'Modification réussie'); */
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Acquisition $acquisition)
    {
        $acquisition->delete();

        return back()->with('success', 'fiche supprimé');
    }
}
