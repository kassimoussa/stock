
<?php $__env->startSection('content'); ?>
<br><br>
    <div class="d-flex justify-content-start">
        <div class="card" style="width: 70%;">
            <div class="card-header d-flex justify-content-between">
                <h3 class="fw-bold">Nouveau Matériel</h3>
                <a href="<?php echo e(url('/stocks')); ?>" class="btn btn-primary fw-bold"> <i class="fas fa-arrow-left"></i> RETOURNER</a>
            </div>

            <div class="card-body">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('fail')): ?>
                    <div class="alert alert-danger">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <form action="store" role="form" method="post" class="form-card">
                    <?php echo csrf_field(); ?>
                    <div class="row ">
                        <div class="form-group mb-2">
                            <label for="materiel" class="h5">Matériel</label>
                            <input type="text" class="form-control" name="materiel" placeholder="Taper le nom du materiel"
                                value="<?php echo e(old('materiel')); ?>">
                            <span class="text-danger"><?php $__errorArgs = ['materiel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group mb-2">
                            <label for="quantite" class="h5">Quantité</label>
                            <input type="text" class="form-control" name="quantite" placeholder="taper la quantité"
                                value="<?php echo e(old('quantite')); ?>">
                            <span class="text-danger"><?php $__errorArgs = ['quantite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                    </div>
                    <div class="row" style="text-align: center; margin-top: 2%;">
                        <div class=" form-group">
                            <button type="submit" name="submit" class="btn btn-primary fw-bold">Ajouter</button>
                            <button type="reset" class="btn btn-default fw-bold">Annuler</button>

                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>

    <style>
        .btn-default{
            background-color: red !important;
            color: white;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('4.layout', ['page' => 'Gestion des stocks', 'pageSlug' => 'stocks'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/4/stock/create.blade.php ENDPATH**/ ?>