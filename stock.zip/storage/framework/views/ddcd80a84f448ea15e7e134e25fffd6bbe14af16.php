<?php
    $sta = "";
    if($status == "attente"){
        $sta = "mise en attente";
    }elseif($status == "rejete"){
        $sta = "rejeté";
    }
?>

<h3> Le chef de SIH  a <?php echo e($sta); ?> la fiche d'intervention n°<?php echo e($fiche); ?>  . </h3>

<h4> Pour voir et modifier la fiche cliquer <a href="http://stock.test/intervention/fiche/<?php echo e($fiche); ?>">ici.</a></h4><?php /**PATH C:\laragon\www\stock\resources\views/emails/intervention/mail5.blade.php ENDPATH**/ ?>