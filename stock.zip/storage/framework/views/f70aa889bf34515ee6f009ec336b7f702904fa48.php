
<?php $__env->startSection('content'); ?>

    <div class="row mt-3">
        <h3 class="fw-bold mt-3">FICHE D'ACQUISITION</h3>
        <div class="row">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('fail')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <form action="addacquisition" role="form" method="post" class="form">
                <?php echo csrf_field(); ?>

                <div class="card col-md-10 mb-3">
                    <h4 class="card-header text-center">Demandeur</h4>
                    <div class="card-body">
                        <div class="mb-1 row">
                            <label class="col-sm-2 col-form-label">Nom: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="nom_demandeur">
                            </div>
                        </div>
                        <div class="mb-1 row">
                            <label class="col-sm-2 col-form-label">Direction: </label>
                            <div class="col-sm-10">
                                <select class="form-select js-select2" name="dir_demandeur" id="direction">
                                    <option value="" disabled selected>Select Direction</option>
                                    <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($direction['sigle']); ?>"><?php echo e($direction['nom']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-1 row">
                            <label class="col-sm-2 col-form-label">Service: </label>
                            <div class="col-sm-10">
                                <select name="service_demandeur" id="serv" class="form-select js-select2"></select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card col-md-10 mb-3">
                    <h4 class="card-header text-center">Materiel et Description
                    </h4>
                    <div class="card-body">
                        <div class="col mb-2">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="nom_mat" id="pcb" value="PC Bureau">
                                <label class="form-check-label" for="pcb">PC Bureau</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="nom_mat" id="pcp" value="PC Portable">
                                <label class="form-check-label" for="pcp">PC Portable</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="nom_mat" id="ai"
                                    value="Accessoires informatiques">
                                <label class="form-check-label" for="ai">Accessoires informatiques</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="nom_mat" id="imp" value="Imprimante">
                                <label class="form-check-label" for="imp">Imprimante</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="nom_mat" id="fax" value="Fax">
                                <label class="form-check-label" for="fax">Fax</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="nom_mat" id="log" value="Logiciel">
                                <label class="form-check-label" for="log">Logiciel</label>
                            </div>
                            <div class="form-check form-check-inline mb-2">
                                <input class="form-check-input" type="radio" name="nom_mat" id="autre">
                                <label class="form-check-label" for="autre">Autre</label>
                            </div>
                        </div>
                        <div class="mb-1 mt-2 row" id="inputautre" style="display:none">
                            <label class="col-sm-2 col-form-label ">Nom: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="nom_mat"
                                    placeholder="Taper le nom du materiel" id="nom_mat_input" disabled>
                            </div>
                        </div>
                        <div class="mb-1 row" id="desc" style="display:none">
                            <label class="col-sm-2 col-form-label">Description: </label>
                            
                            <div class="col-sm-10">
                                <textarea name="description_mat" id="" class="form-control" cols="30" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="mb-1 row" id="marque" style="display:none">
                            <label class="col-sm-2 col-form-label">Marque: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="marque_mat">
                            </div>
                        </div>
                        <div class="mb-1 row" id="processeur" style="display:none">
                            <label class="col-sm-2 col-form-label">Processeur: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="processeur_mat">
                            </div>
                        </div>
                        <div class="mb-1 row" id="ram" style="display:none">
                            <label class="col-sm-2 col-form-label">Mémoire: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="ram_mat">
                            </div>
                        </div>
                        <div class="mb-1 row" id="stockage" style="display:none">
                            <label class="col-sm-2 col-form-label">Stockage: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="stockage_mat">
                            </div>
                        </div>
                        <div class="mb-1 row" id="os" style="display:none">
                            <label class="col-sm-2 col-form-label">S.E: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="os_mat">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-3 mb-5">
                    <div class="col-md-12 form-group">
                        <button type="submit" name="submit" class="btn btn-primary fw-bold">Soumettre</button>
                        <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                        <input type="text" name="date_submit" value="<?php echo e(date('Y-m-d H:i:s')); ?>" hidden>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <style>
        .btn-default:hover {
            background-color: red !important;
            color: white;
        }

        .btn-primary {
            color: white;
        }

        .card-header {
            background: #4F81BD;
            color: white;
        }

    </style>
    <script>
        $(function() {
            $('input[type="radio"]').click(function() {
                if ($(this).attr('id') == "autre") {
                    $("#nom_mat_input").removeAttr('disabled');
                    $("#desc").show();
                    $("#inputautre").show();
                    $("#marque").show();
                    $("#processeur").hide();
                    $("#ram").hide();
                    $("#stockage").hide();
                    $("#os").hide();
                }
                if (($(this).attr('id') == "pcp") || ($(this).attr('id') == "pcb")) {
                    $("#nom_mat_input").prop('disabled', true); 
                    $("#marque").show();
                    $("#processeur").show();
                    $("#ram").show();
                    $("#stockage").show();
                    $("#os").show();
                    $("#inputautre").hide();
                    $("#desc").hide();
                }
                if (($(this).attr('id') == "ai") || ($(this).attr('id') == "imp") || ($(this).attr('id') ==
                        "fax") || ($(this).attr('id') == "log")) {
                    $("#nom_mat_input").prop('disabled', true); 
                    $("#desc").show();
                    $("#marque").show();
                    $("#processeur").hide();
                    $("#ram").hide();
                    $("#stockage").hide();
                    $("#os").hide();
                    $("#inputautre").hide();
                }

            });
        });
    </script>
    <script>
        $('#direction').change(function() {

            var directionID = $(this).val();

            if (directionID) {

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('getServices')); ?>?dir_id=" + directionID,
                    success: function(res) {

                        if (res) {

                            $("#serv").empty();
                            $("#serv").append('<option>Select Service</option>');
                            $.each(res, function(key, value) {
                                $("#serv").append('<option value="' + value + '">' + value +
                                    '</option>');
                            });

                        } else {

                            $("#serv").empty();
                        }
                    }
                });
            } else {

                $("#serv").empty();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('1.layout', ['page' => 'Nouvelle Acquisition', 'pageSlug' => 'acquisition'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/1/acquisition/newacquis.blade.php ENDPATH**/ ?>