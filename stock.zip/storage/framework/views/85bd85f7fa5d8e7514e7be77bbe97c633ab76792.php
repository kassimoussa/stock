
<h3> Fiche d'Acquisition validé </h3>

<p>La fiche d'acquisition n°<?php echo e($ficheId); ?> que vous avez soumis dans le Gestionnaire des  Stock le  <?php echo e(date('d/m/Y à H:i:s', strtotime($date_submit))); ?> viens d'êtres approuvé. <br>
    Pour voir et imprimer   <a href="http://stock.test/acquisition/fiche/<?php echo e($ficheId); ?>">la fiche </a> . </p>
<?php /**PATH C:\laragon\www\stock\resources\views/emails/mail3.blade.php ENDPATH**/ ?>