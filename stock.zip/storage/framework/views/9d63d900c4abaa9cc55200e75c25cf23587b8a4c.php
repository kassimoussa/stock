
<?php $__env->startSection('content'); ?>
<br>
<div class="d-flex justify-content-start">
    <div class="card" style="width: 60%;">
        <h3 class="card-header fw-bold">Profile</h3>

        <div class="card-body">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($message = Session::get('fail')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <form action="changeprofile" role="form" method="post" class="form-card">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row mb-2">

                    <div class="  mb-2 ">
                        <div class="form-group control-label">
                            <label class="control-label">Nom </label>
                            <input type="text" class="form-control" name="name" placeholder="" value="<?php echo e($user->name); ?>"
                                required>
                        </div>
                    </div>
                    <div class=" mb-2">
                        <div class="form-group control-label">
                            <label class="control-label">Email </label>
                            <input type="text" class="form-control" name="email" placeholder=""
                                value="<?php echo e($user->email); ?>" required>
                        </div>
                    </div>
                    <div class="  mb-2">
                        <div class="form-group control-label">
                            <label class="control-label">Password </label>
                            <input type="password" class="form-control" name="password" placeholder=""
                                value="<?php echo e($user->password); ?>" required>
                        </div>
                    </div>
                </div>


                <div class="row" style="text-align: center; margin-top: 2%;">
                    <div class=" form-group">
                        <button type="submit" name="submit" class="btn btn-primary fw-bold">Modifer</button>
                        <button type="reset" class="btn btn-default fw-bold">Annuler</button>

                    </div>
                </div>
            </form>
        </div>
    </div>

</div>
    
    <style>
        .btn-default:hover {
            background-color: red !important;
            color: white;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('3.layout', ['page' => 'Profile', 'pageSlug' => 'profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/3/profile.blade.php ENDPATH**/ ?>