
<h3> Une nouvelle fiche d'intervention a été soumit dans le Gestionnaire des Stock  par <?php echo e($nom_demandeur); ?> du service <?php echo e($service_demandeur); ?> . </h3>

<h4> Pour voir et valider la fiche cliquer sur la rubirique Intervention</h4><?php /**PATH C:\laragon\www\stock\resources\views/emails/intervention/mail1.blade.php ENDPATH**/ ?>