
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-4 mt-4">
            <div class="card border-primary no-radius text-center bg-white">
                <div class="card-body">
                    <span class="fa-stack fa-2x">
                        <i class="fa fa-square fa-stack-2x blciel"></i>
                        <i class="fa fa-warehouse fa-stack-1x dore"></i>
                    </span>
                    <h2 class="StepTitle card-title">Stock</h2>
                    <p class="cl-effect-1">
                        <a href="<?php echo e(url('/stocks')); ?>">
                            Voir le Stock
                        </a>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-sm-4 mt-4">
            <div class="card border-primary no-radius text-center bg-white">
                <div class="card-body">
                    <span class="fa-stack fa-2x">
                        <i class="fa fa-square fa-stack-2x blciel"></i>
                        <i class="fa fa-laptop fa-stack-1x dore"></i>
                    </span>
                    <h2 class="StepTitle card-title">Acqusition</h2>
                    <p class="cl-effect-1">
                        <a href="<?php echo e(url('/acquisition')); ?>">
                            Fiche d'acquisition
                        </a>
                    </p>
                </div>
            </div>
        </div>
        <div class="col-sm-4 mt-4">
            <div class="card border-primary no-radius text-center bg-white">
                <div class="card-body">
                    <span class="fa-stack fa-2x">
                        <i class="fa fa-square fa-stack-2x blciel"></i>
                        <i class="fa fa-tools fa-stack-1x dore"></i>
                    </span>
                    <h2 class="StepTitle card-title">Intervention</h2>
                    <p class="cl-effect-1">
                        <a href="<?php echo e(url('/intervention')); ?>">
                            Fiches d'intervention
                        </a>
                    </p>
                </div>
            </div>
        </div>
        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('4.layout', ['page' => 'Accueil', 'pageSlug' => 'index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/4/index.blade.php ENDPATH**/ ?>