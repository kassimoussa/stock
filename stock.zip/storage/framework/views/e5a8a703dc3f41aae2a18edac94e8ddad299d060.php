
<?php $__env->startSection('content'); ?>

    <div class="row mt-3">
        <h3 class="fw-bold mt-3">Ajout de devis</h3>
        <div class="row">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('fail')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('adddevis')); ?>" role="form" method="post" class="form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card col-md-12 mb-3">
                    <h4 class="card-header text-center">Devis</h4>
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <span class="input-group-text txt fw-bold ">Fournisseur</span>
                            <input type="text" class="form-control" name="fournisseur">
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text txt fw-bold ">N° de devis</span>
                            <input type="text" class="form-control" name="numero_devis">
                        </div>
                        <div class="mb-3">
                            <input class="form-control" type="file" name="file" id="formFile">
                          </div>

                        <div class="row mb-3">
                            <div class="col-md-12 form-group ">
                                <button type="submit" name="submit" class="btn btn-primary fw-bold">Soumettre</button>
                                <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                                <input type="text" name="fiche_intervention" value="<?php echo e($intervention->id); ?>" hidden>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <style>
        .btn-default:hover {
            background-color: red !important;
            color: white;
        }

        .btn-primary {
            color: white;
        }

        .card-header {
            background: #4F81BD;
            color: white;
        }

        .txt {
            width: 133px;
        }

    </style>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('2.sih.layout', ['page' => 'Ajout devis', 'pageSlug' => 'intervention'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/sih/intervention/devis.blade.php ENDPATH**/ ?>