
<h3> Le directeur de la <?php echo e($dir_demandeur); ?> a validé la fiche d'intervention n°<?php echo e($fiche); ?>  . </h3>

<h4> Pour voir et valider la fiche cliquer <a href="http://stock.test/intervention/fiche/<?php echo e($fiche); ?>">ici.</a></h4><?php /**PATH C:\laragon\www\stock\resources\views/emails/intervention/mail2.blade.php ENDPATH**/ ?>