<?php
use App\Models\Direction;
?> 

<?php $__env->startSection('content'); ?>
    <br>
    <div class="container ">
        
        <div class="d-flex justify-content-between mb-4 " >
            <h3 class="over-title ">Fiches de livraison  </h3>
            <a href="<?php echo e(url('/generate-livraison', $livraison)); ?>" class="btn  btn-primary  fw-bold text-white">IMPRIMER</a>
        </div>

        <div class="card  mb-3" style="width: 100%;">
            <h4 class="card-header text-center">Departement</h4>

            <div class="card-body">
                <div class="input-group mb-3">
                    <span class="input-group-text fw-bold ">Nom</span>
                    <label class="form-control"><?php echo e($livraison->nom_intervenant); ?> </label>
                </div>
                <?php
                $dir = Direction::where('sigle', $livraison->direction)->get()->first();
            ?>
                <div class="input-group mb-3">
                    <span class="input-group-text fw-bold">Direction</span>

                    <label class="form-control"><?php echo e($dir->nom); ?> </label>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text fw-bold">Service</span>
                    <label class="form-control"><?php echo e($livraison->service); ?> </label>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text fw-bold">Date d'acquisition</span>
                    <label class="form-control"><?php echo e(date('d/m/Y', strtotime($livraison->date_livraison))); ?> </label>
                </div>
            </div>
        </div>
        <div class="card  mb-3" style="width: 100%;">
            <h4 class="card-header text-center">Materiels Livrés
            </h4>
            <div class="card-body">
                <div class="col mb-2">
                    <table class="table tablesorter  table-bordered" id="">
                        <thead class="table-dark ">
                            <th scope="col">Nom du materile</th>
                            <th scope="col">Quantité</th>
                            <th scope="col">Observation</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $materiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $materiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($materiel->nom_materiel); ?></td>
                                    <td><?php echo e($materiel->quantite); ?></td>
                                    <td><?php echo e($materiel->observation); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        </div>

    </div>
    <style>
        .card-header {
            background: #4F81BD;
            color: white;
        }

        .input-group-text {
            width: 17%;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('2.layout', ['page' => 'Fiche Livraison', 'pageSlug' => 'livraison'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/livraison/show.blade.php ENDPATH**/ ?>