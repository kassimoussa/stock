
<h3> Restitution de mot de passe </h3>

<p>Le code secret est :  <?php echo e($rand); ?> . <br>
    Vous pouvez réinitialiser votre mot de passe en cliquant <a href="http://stock.test/reset">ici</a> . </p>
<?php /**PATH C:\laragon\www\stock\resources\views/emails/reset_password.blade.php ENDPATH**/ ?>