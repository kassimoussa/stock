
<h3> Une nouvelle fiche d'acquisition a été soumit dans le Gestionnaire des Stock  par la <?php echo e($direction); ?> . </h3>

<h4> Il s'agit d'une acquisition de <?php echo e($materiel); ?> pour <?php echo e($nom); ?> du service <?php echo e($service); ?>.  </h4>

<h4> Pour voir et approuver la fiche cliquer sur la rubirique Acquisition</h4><?php /**PATH C:\laragon\www\stock\resources\views/emails/mail1.blade.php ENDPATH**/ ?>