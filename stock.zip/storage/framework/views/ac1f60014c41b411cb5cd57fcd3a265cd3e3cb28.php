
<?php $__env->startSection('content'); ?>
    <br>
    <div class="row mt-3">
        <h3 class="fw-bold mt-3">FICHE D'INTERVENTION</h3>
        <div class="row">
            <div class="col-lg-12">
                <div class="card  mb-3">
                    <h4 class="card-header text-center">Technicien</h4>
                    <div class="card-body">
                        <div class="form-group control-label">
                            <label class="control-label">Nom Intervenant <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="nom_intervenant"
                                value="<?php echo e($intervention->nom_intervenant); ?>" readonly>
                        </div>
                        <div class="form-group control-label">
                            <label class="control-label">Diagnostique <span class="text-danger">*</span></label>
                            <textarea name="diagnostique" id="" class="form-control" cols="30" rows="2"
                                readonly><?php echo e($intervention->diagnostique); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-12">
                <div class="card mb-3">
                    <h4 class="card-header text-center">Informations </h4>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card ">
                                    <h4 class="card-header ch2 text-center">Sur le materiel</h4>
                                    <div class="card-body">
                                        <div class="form-group control-label">
                                            <label class="control-label">Materiel <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="materiel"
                                                value="<?php echo e($intervention->materiel); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Model <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="model"
                                                value="<?php echo e($intervention->model); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Réf patrimoine <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="ref_patrimoine"
                                                value="<?php echo e($intervention->ref_patrimoine); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Date d'acquisition </label>
                                            <input type="text" class="form-control" name="date_acquisition"
                                                value="<?php echo e(date('d/m/Y', strtotime($intervention->date_acquisition))); ?>"
                                                readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card ">
                                    <h4 class="card-header ch2 text-center">Sur le demandeur</h4>
                                    <div class="card-body">
                                        <div class="form-group control-label">
                                            <label class="control-label">Propriétaire <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="nom_demandeur"
                                                value="<?php echo e($intervention->nom_demandeur); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Direction ou Département <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="dir_demandeur"
                                                value="<?php echo e($intervention->dir_demandeur); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Centre ou Service <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="service_demandeur"
                                                value="<?php echo e($intervention->service_demandeur); ?>" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                
                    

            <div class="col-lg-12">
                <div class="card  mb-3">
                    <h4 class="card-header text-center">Direction demandeuse</h4>
                    <div class="card-body">
                        <?php
                            $approuve = $attente = $rejete = $button = $date = ' ';
                            
                            if ($intervention->status_dir == 'approuve') {
                                $approuve = 'checked';
                                $button = 'hidden';
                                $attente = $rejete = ' disabled '; 
                            } elseif ($intervention->status_dir == 'attente') {
                                $date = 'hidden ';
                                $attente = 'checked'; /* $approuve = $rejete =  ' disabled ' */
                            } elseif ($intervention->status_dir == 'rejete') {
                                $date = 'hidden ';
                                $rejete = 'checked'; /* $approuve = $attente =  ' disabled ' */
                            }
                        ?>
                        <?php if($intervention->status_dir == null): ?>

                        <form action="<?php echo e(url('/intervention/dirvalide', $intervention)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                        <div class="col-md-12">
                            <div class="form-check form-check-inline text-center">
                                <input class="form-check-input" type="radio" name="status_dir" id="Approuver"
                                    value="approuve" <?php echo e($approuve); ?>>
                                <label class="form-check-label" for="Approuver">Approuver</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status_dir" id="attente"
                                    value="attente" <?php echo e($attente); ?>>
                                <label class="form-check-label" for="attente">En attente</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status_dir" id="rejete"
                                    value="rejete" <?php echo e($rejete); ?>>
                                <label class="form-check-label" for="rejete">Rejeter</label>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text fw-bold">Commentaire</span>
                            <textarea name="commentaire" id="" class="form-control" cols="30"
                                rows="2" ><?php echo e($intervention->commentaire); ?></textarea>
                        </div>                        
                        <div class="row" style=" margin-top: 2%;" <?php echo e($button); ?>>
                            <div class="col-md-12 form-group ">
                                <button type="submit" name="submit" class="btn btn-primary fw-bold">Soumettre</button>
                                <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                                <input type="text" name="date_dir" value="<?php echo e(date('Y-m-d H:i:s')); ?>" hidden>
                            </div>
                        </div>  
                        </form>
                        <?php else: ?>
                        <form action="<?php echo e(url('/intervention/dirvalide', $intervention)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                        <div class="col-md-12">
                            <div class="form-check form-check-inline text-center">
                                <input class="form-check-input" type="radio" name="status_dir" id="Approuver"
                                    value="approuve" <?php echo e($approuve); ?>>
                                <label class="form-check-label" for="Approuver">Approuver</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status_dir" id="attente"
                                    value="attente" <?php echo e($attente); ?>>
                                <label class="form-check-label" for="attente">En attente</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status_dir" id="rejete"
                                    value="rejete" <?php echo e($rejete); ?>>
                                <label class="form-check-label" for="rejete">Rejeter</label>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text fw-bold">Commentaire</span>
                            <textarea name="commentaire" id="" class="form-control" cols="30"
                                rows="2" ><?php echo e($intervention->commentaire); ?></textarea>
                        </div>
                        <div <?php echo e($date); ?>>
                            <div class="input-group mb-3" >
                            <span class="input-group-text fw-bold">Date</span>
                            <label
                                class="form-control"><?php echo e(date('d/m/Y', strtotime($intervention->date_dir))); ?>

                            </label>
                        </div>
                        </div>
                        
                        <div class="row" style=" margin-top: 2%;" <?php echo e($button); ?>>
                            <div class="col-md-12 form-group ">
                                <button type="submit" name="submit" class="btn btn-primary fw-bold">Soumettre</button>
                                <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                                <input type="text" name="date_dir" value="<?php echo e(date('Y-m-d H:i:s')); ?>" hidden>
                            </div>
                        </div>  
                        </form>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
            

            <?php if($intervention->status_dir == 'approuve'): ?>
                <div class="col-lg-12">
                    <div class="card  mb-3">
                        <h4 class="card-header text-center">DIN</h4>
                        <div class="card-body">
                            <?php
                                $approuve = $attente = $rejete = $sugg = $button = ' ';
                                
                                if ($intervention->status_din == 'approuve') {
                                    $approuve = 'checked';
                                    $button = 'hidden';
                                    $attente = $rejete = $sugg = ' disabled ';
                                } elseif ($intervention->status_din == 'attente') {
                                    $attente = 'checked';  $approuve = $rejete =  ' disabled ' ;
                                } elseif ($intervention->status_din == 'rejete') {
                                    $rejete = 'checked'; $approuve = $attente =  ' disabled '; 
                                }
                            ?>
                            <?php if($intervention->status_din != null): ?>
                            <div class="col-md-12">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_din" id="Approuver"
                                        value="approuve" <?php echo e($approuve); ?>>
                                    <label class="form-check-label" for="Approuver">Approuver</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_din" id="attente"
                                        value="attente" <?php echo e($attente); ?>>
                                    <label class="form-check-label" for="attente">En attente</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_din" id="rejete"
                                        value="rejete" <?php echo e($rejete); ?>>
                                    <label class="form-check-label" for="rejete">Rejeter</label>
                                </div>
                            </div>
                            <div class="input-group mb-3">
                                <span class="input-group-text fw-bold">Avis</span>
                                <textarea name="suggestion" id="" class="form-control" cols="30" rows="2"
                                    readonly><?php echo e($intervention->avis); ?></textarea>
                            </div>
                            <div class="input-group mb-3">
                                <span class="input-group-text fw-bold">Date</span>
                                <label
                                    class="form-control"><?php echo e(date('d/m/Y', strtotime($intervention->date_din ))); ?>

                                </label>
                            </div>
                            <?php else: ?>
                            <div class="alert alert-danger">
                                <h3 class="fw-bold"> Le chef de DIN n'a pas encore
                                    approuvé la fiche d'intervention </h3>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
        </div>
    </div>
    <style>
        .card-header {
            background: #4F81BD;
            color: white;
        }

        .ch2 {
            background: #12151A;
            color: white;
        }

        .input-group-text {
            width: 13%;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('2.layout', ['page' => 'Fiche Intervention', 'pageSlug' => 'intervention'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/intervention/show.blade.php ENDPATH**/ ?>