<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <title>Register </title>
</head>

<body>
    <div class="container ">
        <h1 class="mt-3 fw-bold text-center" style="color: #002565 ">Gestion des Stock</h1>
            <div class=" d-flex justify-content-center align-content-center mt-5"  >
                <div class="col-sm-6">
                    <h4 class="fw-bold">Inscription</h4>
                <hr>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('fail')): ?>
                    <div class="alert alert-danger">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row ">
                        <div class="form-group mb-1 col-md-6">
                            <label for="name" class="control-label h5">Level</label>
                            <select name="level" class="form-control ">
                                <option value=""disabled selected>Selectionner le niveau</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                            <span class="text-danger"><?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group control-label mb-1 col-md-6">
                            <label class="control-label h5">Direction </label>
                            <select class="form-select" name="direction" >
                                <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($direction['sigle']); ?>"><?php echo e($direction['nom']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group control-label mb-1">
                            <label class="control-label h5">Nom </label>
                            <input type="text" class="form-control" name="name" placeholder=" Entrer votre nom " value="<?php echo e(old('email')); ?>"
                                required>
                                <span class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group mb-1 ">
                            <label for="email" class="control-label h5">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Entrer votre email"
                                value="<?php echo e(old('email')); ?>">
                            <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group mb-1">
                            <label for="password" class="control-label h5">Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Entrer votre mot de passe"
                                value="<?php echo e(old('password')); ?>">
                            <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                    </div>
                    <div class="form-group mb-1 d-grid">
                        <button type="submit" class="btn  btn-primary fw-bold">Ajouter</button>
                    </div>
                    <a href="/">Se connecter </a>
                </form>
            </div>
        </div>


    </div>
    <div class="text-center">
        <h5>

        </h5>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\stock\resources\views/auth/register.blade.php ENDPATH**/ ?>