
<?php $__env->startSection('content'); ?>

    <div class="row  py-3 px-3">
        <div class="d-flex justify-content-between mb-2">
            <h3 class="over-title ">Fiches d'intervention  </h3>
        </div>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <?php if($message = Session::get('fail')): ?>
            <div class="alert alert-danger">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div>
            <table class="table tablesorter  " id="">
                <thead class=" text-primary">
                    <th scope="col">N° Fiche</th>
                    <th scope="col">Nom demandeur</th>
                    <th scope="col">Service</th>
                    <th scope="col">Materiel</th>
                    <th scope="col" colspan="3">Status</th>
                    <th scope="col">Date d'intervention</th>
                    <th scope="col">Action</th>
                </thead>
                <tbody>
                    <?php if(!empty($interventions) && $interventions->count()): ?>
                    <?php
                            $cnt = 1;
                        ?>

                    <?php $__currentLoopData = $interventions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $intervention): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php
                            $status_dir = '';
                            $status_sih = '';
                            $status_din = '';
                            $btnhidden = '';

                                if($intervention->status_dir == 'approuve'){ $status_dir = '#089415'; }
                                elseif($intervention->status_dir == 'attente'){ $status_dir = '#efaa2d'; }
                                elseif($intervention->status_dir == 'rejete'){ $status_dir = '#FF0000'; }
                                elseif($intervention->status_dir == null){ $status_dir = '#FFFFFF'; }

                                if($intervention->status_sih == 'approuve'){ $status_sih = '#089415'; $btnhidden = 'hidden'; }
                                elseif($intervention->status_sih == 'attente'){ $status_sih = '#efaa2d'; }
                                elseif($intervention->status_sih == 'rejete'){ $status_sih = '#FF0000'; }
                                elseif($intervention->status_sih == null){ $status_sih = '#FFFFFF'; }
                                
                                if($intervention->status_din == 'approuve'){ $status_din = '#089415'; $btnhidden = 'hidden'; }
                                elseif($intervention->status_din == 'attente'){ $status_din = '#efaa2d'; }
                                elseif($intervention->status_din == 'rejete'){ $status_din = '#FF0000'; }
                                elseif($intervention->status_din == null){ $status_din = '#FFFFFF'; }
                            ?>
                            <td><?php echo e($intervention->id); ?></td>
                            <td><?php echo e($intervention->nom_demandeur); ?></td>
                            <td><?php echo e($intervention->service_demandeur); ?></td>
                            <td><?php echo e($intervention->materiel); ?></td>
                            <td style="background: <?php echo e($status_sih); ?>" >SIH</td>
                            <td style="background: <?php echo e($status_dir); ?>"><?php echo e($intervention->dir_demandeur); ?></td>                            
                            <td style="background: <?php echo e($status_din); ?>">DIN</td>
                            <td><?php echo e(date('d/m/Y', strtotime($intervention->date_intervention))); ?></td>
                            <td class="td-actions ">
                                <a href="<?php echo e(url('/intervention/fiche', $intervention)); ?>" class="btn btn-link" data-bs-toggle="tooltip" data-bs-placement="left"
                                    title="Voir la fiche">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(url('/intervention/edit', $intervention)); ?>" class="btn btn-link" data-bs-toggle="tooltip" data-bs-placement="bottom" <?php echo e($btnhidden); ?>

                                    title="Modifier la fiche">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(url('/intervention/delete', $intervention)); ?>" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="button" class="btn btn-link" data-bs-toggle="tooltip"
                                        data-bs-placement="top"  title="Supprimer la fiche"
                                        onclick="confirm('Etes vous sûr de supprimer la fiche ?') ? this.parentElement.submit() : ''">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>                               
                            </td>
                        </tr>
                        <?php
                        $cnt = $cnt +1;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10">There are no data.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($interventions->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('2.layout', ['page' => 'Fiches d\'Intervention', 'pageSlug' => 'intervention'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/intervention/index.blade.php ENDPATH**/ ?>