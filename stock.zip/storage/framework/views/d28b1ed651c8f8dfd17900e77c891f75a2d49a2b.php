<!DOCTYPE html>
<html>
<head>
    <title>Hi</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="../boot/bootstrap.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
</head>
<body>
    <br>
    <div class="container ">
        <div class="d-flex justify-content-between mb-3" style="width: 80%">
            <h3 class="over-title ">FICHE D'ACQUISITION </h3>
        </div>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success" style="width: 80%">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <?php if($message = Session::get('fail')): ?>
            <div class="alert alert-danger" style="width: 80%">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div class="card  mb-3" style="width: 80%;">
            <h4 class="card-header text-center">Demandeur</h4>

            <div class="card-body">
                <div class="input-group mb-3">
                    <span class="input-group-text fw-bold ">Nom</span>
                    <label class="form-control"><?php echo e($acquisition->nom_demandeur); ?> </label>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text fw-bold">Direction</span>

                    <label class="form-control"><?php echo e($acquisition->dir_demandeur); ?> </label>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text fw-bold">Service</span>
                    <label class="form-control"><?php echo e($acquisition->service_demandeur); ?> </label>
                </div>
            </div>
        </div>
        <div class="card  mb-3" style="width: 80%;">
            <h4 class="card-header text-center">Materiel et Description
            </h4>
            <div class="card-body">
                <div class="col mb-2">
                    <?php
                        $pcb = ' ';
                        $pcp = ' ';
                        $ai = ' ';
                        $imp = ' ';
                        $fax = ' ';
                        $log = ' ';
                        $autre = ' ';
                        
                        if ($acquisition->nom_mat == 'PC Bureau') {
                            $pcb = 'checked';
                            $pcp = $ai = $imp = $fax = $log = $autre = ' disabled ';
                            $nomdiv = 'hidden';
                            $descdiv = 'hidden';
                            $procediv = ' ';
                            $ramdiv = ' ';
                            $stockdiv = ' ';
                            $sediv = ' ';
                        } elseif ($acquisition->nom_mat == 'PC Portable') {
                            $pcp = 'checked';
                            $pcb = $ai = $imp = $fax = $log = $autre = ' disabled ';
                            $nomdiv = 'hidden';
                            $descdiv = 'hidden';
                            $procediv = ' ';
                            $ramdiv = ' ';
                            $stockdiv = ' ';
                            $sediv = ' ';
                            $disabled = ' ';
                        } elseif ($acquisition->nom_mat == 'Accessoires informatiques') {
                            $ai = 'checked';
                            $pcb = $pcp = $imp = $fax = $log = $autre = ' disabled ';
                            $nomdiv = 'hidden';
                            $descdiv = ' ';
                            $procediv = 'hidden';
                            $ramdiv = 'hidden';
                            $stockdiv = 'hidden';
                            $sediv = 'hidden';
                            $disabled = ' ';
                        } elseif ($acquisition->nom_mat == 'Imprimante') {
                            $imp = 'checked';
                            $pcb = $pcp = $ai = $fax = $log = $autre = ' disabled ';
                            $nomdiv = 'hidden';
                            $descdiv = ' ';
                            $procediv = 'hidden';
                            $ramdiv = 'hidden';
                            $stockdiv = 'hidden';
                            $sediv = 'hidden';
                            $disabled = ' ';
                        } elseif ($acquisition->nom_mat == 'Fax') {
                            $fax = 'checked';
                            $pcb = $pcp = $imp = $ai = $log = $autre = ' disabled ';
                            $nomdiv = 'hidden';
                            $descdiv = '';
                            $procediv = 'hidden';
                            $ramdiv = 'hidden';
                            $stockdiv = 'hidden';
                            $sediv = 'hidden';
                            $disabled = ' ';
                        } elseif ($acquisition->nom_mat == 'Logiciel') {
                            $log = 'checked';
                            $pcb = $pcp = $imp = $fax = $ai = $autre = ' disabled ';
                            $nomdiv = 'hidden';
                            $descdiv = '';
                            $procediv = 'hidden';
                            $ramdiv = 'hidden';
                            $stockdiv = 'hidden';
                            $sediv = 'hidden';
                            $disabled = ' ';
                        } else {
                            $autre = 'checked';
                            $pcb = $pcp = $imp = $fax = $log = $ai = ' disabled ';
                            $nomdiv = ' ';
                            $descdiv = '';
                            $procediv = 'hidden';
                            $ramdiv = 'hidden';
                            $stockdiv = 'hidden';
                            $sediv = 'hidden';
                            $disabled = ' ';
                        }
                    ?>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="nom_mat" id="pcb" value="PC Bureau"
                            <?php echo e($pcb); ?>>
                        <label class="form-check-label" for="pcb">PC Bureau</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="nom_mat" id="pcp" value="PC Portable"
                            <?php echo e($pcp); ?>>
                        <label class="form-check-label" for="pcp">PC Portable</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="nom_mat" id="ai"
                            value="Accessoires informatiques" <?php echo e($ai); ?>>
                        <label class="form-check-label" for="ai">Accessoires informatiques</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="nom_mat" id="imp" value="Imprimante"
                            <?php echo e($imp); ?>>
                        <label class="form-check-label" for="imp">Imprimante</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="nom_mat" id="fax" value="Fax"
                            <?php echo e($fax); ?>>
                        <label class="form-check-label" for="fax">Fax</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="nom_mat" id="log" value="Logiciel"
                            <?php echo e($log); ?>>
                        <label class="form-check-label" for="log">Logiciel</label>
                    </div>
                    <div class="form-check form-check-inline mb-2">
                        <input class="form-check-input" type="radio" name="nom_mat" id="autre" <?php echo e($autre); ?>>
                        <label class="form-check-label" for="autre">Autre</label>
                    </div>
                </div>
                <div class="input-group mb-2" <?php echo e($nomdiv); ?>>
                    <span class="input-group-text fw-bold">Nom</span>
                    <label class="form-control"><?php echo e($acquisition->nom_mat); ?> </label>
                </div>

                <div class="input-group mb-2" <?php echo e($descdiv); ?>>
                    <span class="input-group-text fw-bold">Description</span>
                    <label class="form-control"><?php echo e($acquisition->description_mat); ?> </label>
                </div>

                <div class="input-group mb-2">
                    <span class="input-group-text fw-bold">Marque</span>
                    <label class="form-control"><?php echo e($acquisition->marque_mat); ?> </label>
                </div>

                <div class="input-group mb-2" <?php echo e($procediv); ?>>
                    <span class="input-group-text fw-bold">Processeur</span>
                    <label class="form-control"><?php echo e($acquisition->processeur_mat); ?> </label>
                </div>

                <div class="input-group mb-2" <?php echo e($ramdiv); ?>>
                    <span class="input-group-text fw-bold">Mémoire</span>
                    <label class="form-control"><?php echo e($acquisition->ram_mat); ?> </label>
                </div>

                <div class="input-group mb-2" <?php echo e($stockdiv); ?>>
                    <span class="input-group-text fw-bold">Stockage</span>
                    <label class="form-control"><?php echo e($acquisition->stockage_mat); ?> </label>
                </div>

                <div class="input-group mb-2" <?php echo e($sediv); ?>>
                    <span class="input-group-text fw-bold">S.E</span>
                    <label class="form-control"><?php echo e($acquisition->os_mat); ?> </label>
                </div>
            </div>
        </div>

        


        <?php if($acquisition->sign_rep_demandeur == 1 && $acquisition->sign_dir_dsi == 0): ?>
            <?php if($acquisition->dir_demandeur != 'DSI'): ?>
                <div class="card  mb-3" style="width: 80%;">
                    <h4 class="card-header text-center">Visa Directeur ou Chef de département demandeur</h4>
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div class="col-md-4 ">
                                <label class="">Date :
                                    <?php echo e(date('d/m/Y à H:i:s', strtotime($acquisition->date_dir_ok))); ?> </label>
                            </div>

                            <div class="form-check col-md-4">
                                <span class="fw-bold">Le Directeur de la <?php echo e($acquisition->dir_demandeur); ?> </span>
                                <input class="form-check-input" type="checkbox" value="true" checked disabled>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card  mb-3" style="width: 80%;">
                <h4 class="card-header text-center">Visa DSI
                </h4>
                <div class="card-body">
                    <div>
                        <form action="<?php echo e(url('/acquisition/dsivalide', $acquisition)); ?>" role="form" method="post"
                            class="form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("PUT"); ?>
                            <div class="row mt-3 mb-2">
                                <div class="mb-2 row" hidden>
                                    <label class="col-md-2  col-form-label">Commentaires: </label>

                                    <div class="col-md-10">
                                        <textarea name="commentaires" class="form-control" cols="30" rows="2"> </textarea>
                                    </div>
                                </div>
                                <div class="col-md-12 form-group text-center">
                                    <button type="submit" name="submit" class="btn btn-primary fw-bold">VALIDER</button>
                                    <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                                    <input type="text" name="date_dir_ok" value="<?php echo e(date('Y-m-d H:i:s')); ?>" hidden>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        <?php elseif(($acquisition->sign_rep_demandeur == 1) && ($acquisition->sign_dir_dsi == 1)): ?>

            <?php if($acquisition->dir_demandeur != 'DSI'): ?>
                <div class="card  mb-3" style="width: 80%;">
                    <h4 class="card-header text-center">Visa Directeur ou Chef de département demandeur</h4>
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div class="col-md-4 ">
                                <label class="">Date :
                                    <?php echo e(date('d/m/Y à H:i:s', strtotime($acquisition->date_dir_ok))); ?> </label>
                            </div>

                            <div class="form-check col-md-4">
                                <span class="fw-bold">Le Directeur de la <?php echo e($acquisition->dir_demandeur); ?> </span>
                                <input class="form-check-input" type="checkbox" value="true" checked disabled>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card  mb-3" style="width: 80%;">
                <h4 class="card-header text-center">Visa DSI</h4>
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div class="col-md-4 ">
                            <label class="">Date :
                                <?php echo e(date('d/m/Y à H:i:s', strtotime($acquisition->date_ok))); ?> </label>
                        </div>

                        <div class="form-check col-md-4">
                            <span class="fw-bold">Le Directeur de la DSI </span>
                            <input class="form-check-input" type="checkbox" value="true" checked disabled>
                        </div>
                    </div>
                </div>
            </div>

        <?php endif; ?>
    </div>
    <style>
        .btn-default:hover {
            background-color: red !important;
            color: white;
        }


        .card-header {
            background: #4F81BD;
            color: white;
        }

        .input-group-text {
            width: 13%;
        }

    </style>
</body>
</html><?php /**PATH C:\laragon\www\stock\resources\views/1/acquisition/fiches.blade.php ENDPATH**/ ?>