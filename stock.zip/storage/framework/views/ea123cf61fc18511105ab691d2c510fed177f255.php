
<h3> Le chef de SIH a validé la fiche d'intervention n°<?php echo e($fiche); ?>  . </h3>

<h4> Pour voir et valider la fiche cliquer <a href="http://stock.test/intervention/fiche/<?php echo e($fiche); ?>">ici.</a></h4><?php /**PATH C:\laragon\www\stock\resources\views/emails/intervention/mail4.blade.php ENDPATH**/ ?>