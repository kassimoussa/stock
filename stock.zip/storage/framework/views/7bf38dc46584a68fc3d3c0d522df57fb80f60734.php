
<?php $__env->startSection('content'); ?>

    <div class="row  py-3 px-3">
        <div class="d-flex justify-content-between mb-4 ">
            <h3 class="over-title ">Fiches de livraison  </h3>
            <a href="/livraison/newlivraison" class="btn  btn-primary  fw-bold">Nouvelle Livraison</a>
        </div>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <?php if($message = Session::get('fail')): ?>
            <div class="alert alert-danger">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div>
            <table class="table tablesorter " id="">
                <thead class=" text-primary">
                    <th scope="col">N° Fiche</th>
                    <th scope="col">Nom de l'intervenant</th>
                    <th scope="col">Direction</th>
                    <th scope="col">Action</th>
                </thead>
                <tbody>
                    <?php if(!empty($livraisons) && $livraisons->count()): ?>
                    <?php
                            $cnt = 1;
                        ?>

                    <?php $__currentLoopData = $livraisons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $livraison): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($livraison->id); ?></td>
                            <td><?php echo e($livraison->nom_intervenant); ?></td>
                            <td><?php echo e($livraison->direction); ?></td>
                            <td class="td-actions ">
                                <a href="<?php echo e(url('/livraison/show', $livraison)); ?>" class="btn btn-link" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Voir la fiche <?php echo e($livraison->id); ?>">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php
                        $cnt = $cnt +1;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10">There are no data.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
           
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('2.sih.layout', ['page' => 'Fiches de livraison', 'pageSlug' => 'livraison'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/sih/livraison/index.blade.php ENDPATH**/ ?>