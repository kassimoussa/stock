
<?php $__env->startSection('content'); ?>

    <div class="row mt-3">
        <h3 class="fw-bold mt-3">Gestion des stocks</h3>
        <div class="row">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('fail')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(url('/stocks/ajout', $stock)); ?>" role="form" method="post" class="form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="card col-md-12 mb-3">
                    <h4 class="card-header text-center">Rentrée de stock</h4>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="input-group mb-3 ">
                                    <span class="input-group-text txt fw-bold ">Materiel</span>
                                    <input type="text" class="form-control" name="materiel"
                                        value="<?php echo e($stock->materiel); ?>" readonly>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="input-group mb-3 mb-3">
                                    <span class="input-group-text txt fw-bold ">Quantité</span>
                                    <input type="text" class="form-control" name="quantite"
                                        placeholder="Quantité disponible: <?php echo e($stock->quantite); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group mb-3 ">
                                    <span class="input-group-text txt fw-bold ">Fournisseur</span>
                                    <input type="text" class="form-control" name="fournisseur" >
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="input-group mb-3 mb-3">
                                    <span class="input-group-text txt fw-bold ">Date</span>
                                    <input type="date" class="form-control" name="date_rentree">
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="row mt-3 mb-5">
                    <div class="col-md-12 form-group">
                        <button type="submit" name="submit" class="btn btn-primary fw-bold">Soumettre</button>
                        <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                    </div>
                </div>
            </form>
        </div>
        <br>
        <div class="col-md-12">
            <h3>Dernières Rentrées pour <?php echo e($stock->materiel); ?></h3>
            <table class="table table-bordered border-dark " id="">
                <thead class="  table-dark">
                    <th scope="col">#</th>
                    <th scope="col">Quantité</th>
                    <th scope="col">Fournisseur</th>
                    <th scope="col">Date</th>
                </thead>
                <tbody>
                    <?php if(!empty($rentrees) && $rentrees->count()): ?>
                        <?php
                            $cnt = 1;
                        ?>

                        <?php $__currentLoopData = $rentrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rentree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($cnt); ?></td>
                                <td><?php echo e($rentree->quantite); ?></td>
                                <td><?php echo e($rentree->fournisseur); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($rentree->date_rentree))); ?></td>
                            </tr>
                            <?php
                                $cnt = $cnt + 1;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10">There are no data.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <style>
        .btn-default:hover {
            background-color: red !important;
            color: white;
        }

        .btn-primary {
            color: white;
        }

        .card-header {
            background: #4F81BD;
            color: white;
        }
        .txt {
            width: 20%;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('3.layout', ['page' => 'Gestion des stocks', 'pageSlug' => 'stocks'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/3/stock/rentree.blade.php ENDPATH**/ ?>