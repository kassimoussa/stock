
<?php $__env->startSection('content'); ?>
    <br>
    <div class="row mt-3">
        <h3 class="fw-bold mt-3">FICHE D'INTERVENTION</h3>
        <div class="row">
            <div class="col-lg-12">
                <div class="card  mb-3">
                    <h4 class="card-header text-center">Technicien</h4>
                    <div class="card-body">
                        <div class="form-group control-label">
                            <label class="control-label">Nom Intervenant <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="nom_intervenant"
                                value="<?php echo e($intervention->nom_intervenant); ?>" readonly>
                        </div>
                        <div class="form-group control-label">
                            <label class="control-label">Diagnostique <span class="text-danger">*</span></label>
                            <textarea name="diagnostique" id="" class="form-control" cols="30" rows="2"
                                readonly><?php echo e($intervention->diagnostique); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-12">
                <div class="card mb-3">
                    <h4 class="card-header text-center">Informations </h4>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card ">
                                    <h4 class="card-header ch2 text-center">Sur le materiel</h4>
                                    <div class="card-body">
                                        <div class="form-group control-label">
                                            <label class="control-label">Materiel <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="materiel"
                                                value="<?php echo e($intervention->materiel); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Model <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="model"
                                                value="<?php echo e($intervention->model); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Réf patrimoine <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="ref_patrimoine"
                                                value="<?php echo e($intervention->ref_patrimoine); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Date d'acquisition </label>
                                            <input type="text" class="form-control" name="date_acquisition"
                                                value="<?php echo e(date('d/m/Y', strtotime($intervention->date_acquisition))); ?>"
                                                readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card ">
                                    <h4 class="card-header ch2 text-center">Sur le demandeur</h4>
                                    <div class="card-body">
                                        <div class="form-group control-label">
                                            <label class="control-label">Propriétaire <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="nom_demandeur"
                                                value="<?php echo e($intervention->nom_demandeur); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Direction ou Département <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="dir_demandeur"
                                                value="<?php echo e($intervention->dir_demandeur); ?>" readonly>
                                        </div>
                                        <div class="form-group control-label">
                                            <label class="control-label">Centre ou Service <span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="service_demandeur"
                                                value="<?php echo e($intervention->service_demandeur); ?>" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card ">
                                    <h4 class="card-header ch2 text-center">Devis</h4>
                                    <div class="card-body">
                                        <div class="col mb-2">
                                            <?php if(!empty($devis) && $devis->count()): ?>
                                            <table class="table tablesorter  table-bordered" id="">
                                                <thead class="table-dark ">
                                                    <th scope="col">N° devis</th>
                                                    <th scope="col">Fournisseur</th>
                                                    <th scope="col">Actions</th>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $cnt = 1;
                                                        $modaln = 'vdir' . $cnt;
                                                    ?>
                                                    <?php $__currentLoopData = $devis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $devi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <tr>
                                                            <td><?php echo e($devi->numero_devis); ?></td>
                                                            <td><?php echo e($devi->fournisseur); ?></td>
                                                            <td class="td-actions ">
                                                                <a href="#" class="btn btn-link" data-bs-toggle="modal"
                                                                    data-bs-target="#<?php echo e($modaln); ?>">
                                                                    <i class="fas fa-eye" data-bs-toggle="tooltip"
                                                                        data-bs-placement="left"
                                                                        title="Voir le devis"></i>
                                                                </a>
                                                                <a href="<?php echo e(url('/intervention/download', $devi)); ?>"
                                                                    class="btn btn-link" data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom" title="Télécharger le devis">
                                                                    <i class="fas fa-download"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <div class="modal fade" id="<?php echo e($modaln); ?>" tabindex="-1"
                                                            aria-labelledby="voirtoutrTitle" aria-hidden="true">
                                                            <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable"
                                                                role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button"
                                                                            class="btn btn-primary fw-bold"
                                                                            data-bs-dismiss="modal">Fermer</button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <iframe height="900px" width="1000px"
                                                                            src="<?php echo e(asset($devi->path)); ?>"
                                                                            frameborder="0"></iframe>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                            $cnt = $cnt + 1;
                                                            $modaln = 'vdir' . $cnt;
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                            <?php else: ?>
                                            <div class="alert alert-dark">
                                                <h3 class="fw-bold"> Il n'y a pas de devis pour cette fiche  </h3>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-12">
                <div class="card  mb-3">
                    <h4 class="card-header text-center">SIH</h4>
                    <div class="card-body">
                        <?php
                            $approuve = $attente = $rejete = $button = $date = ' ';
                            
                            if ($intervention->status_sih == 'approuve') {
                                $approuve = 'checked';
                                $button = 'hidden';
                                $attente = $rejete = ' disabled ';
                            } elseif ($intervention->status_sih == 'attente') {
                                $date = 'hidden ';
                                $attente = 'checked'; /* $approuve = $rejete =  ' disabled ' */
                            } elseif ($intervention->status_sih == 'rejete') {
                                $date = 'hidden ';
                                $rejete = 'checked'; /* $approuve = $attente =  ' disabled ' */
                            }
                        ?>
                        <?php if($intervention->status_sih == null): ?>

                            <form action="<?php echo e(url('/intervention/sihvalide', $intervention)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="col-md-12">
                                    <div class="form-check form-check-inline ">
                                        <input class="form-check-input" type="radio" name="status_sih" id="Approuver"
                                            value="approuve" <?php echo e($approuve); ?>>
                                        <label class="form-check-label" for="Approuver">Approuver</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_sih" id="attente"
                                            value="attente" <?php echo e($attente); ?>>
                                        <label class="form-check-label" for="attente">En attente</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_sih" id="rejete"
                                            value="rejete" <?php echo e($rejete); ?>>
                                        <label class="form-check-label" for="rejete">Rejeter</label>
                                    </div>
                                </div>
                                <div class="input-group mb-3">
                                    <span class="input-group-text fw-bold">Suggestion</span>
                                    <textarea name="suggestion" id="" class="form-control" cols="30"
                                        rows="2"><?php echo e($intervention->suggestion); ?></textarea>
                                </div>
                                <div class="row" style=" margin-top: 2%;" <?php echo e($button); ?>>
                                    <div class="col-md-12 form-group ">
                                        <button type="submit" name="submit"
                                            class="btn btn-primary fw-bold">Soumettre</button>
                                        <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                                        <input type="text" name="date_sih" value="<?php echo e(date('Y-m-d H:i:s')); ?>" hidden>
                                    </div>
                                </div>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(url('/intervention/sihvalide', $intervention)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="col-md-12">
                                    <div class="form-check form-check-inline ">
                                        <input class="form-check-input" type="radio" name="status_sih" id="Approuver"
                                            value="approuve" <?php echo e($approuve); ?>>
                                        <label class="form-check-label" for="Approuver">Approuver</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_sih" id="attente"
                                            value="attente" <?php echo e($attente); ?>>
                                        <label class="form-check-label" for="attente">En attente</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_sih" id="rejete"
                                            value="rejete" <?php echo e($rejete); ?>>
                                        <label class="form-check-label" for="rejete">Rejeter</label>
                                    </div>
                                </div>
                                <div class="input-group mb-3">
                                    <span class="input-group-text fw-bold">Suggestion</span>
                                    <textarea name="suggestion" id="" class="form-control" cols="30"
                                        rows="2"><?php echo e($intervention->suggestion); ?></textarea>
                                </div>
                                <div <?php echo e($date); ?>>
                                    <div class="input-group mb-3">
                                        <span class="input-group-text fw-bold">Date</span>
                                        <label
                                            class="form-control"><?php echo e(date('d/m/Y', strtotime($intervention->date_sih))); ?>

                                        </label>
                                    </div>
                                </div>

                                <div class="row" style=" margin-top: 2%;" <?php echo e($button); ?>>
                                    <div class="col-md-12 form-group ">
                                        <button type="submit" name="submit"
                                            class="btn btn-primary fw-bold">Soumettre</button>
                                        <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                                        <input type="text" name="date_sih" value="<?php echo e(date('Y-m-d H:i:s')); ?>" hidden>
                                    </div>
                                </div>
                            </form>

                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if($intervention->status_sih == 'approuve'): ?>
                <div class="col-lg-12">
                    <div class="card  mb-3">
                        <h4 class="card-header text-center">Direction Demandeuse</h4>
                        <div class="card-body">
                            <?php
                                $approuve = $attente = $rejete = $sugg = $button = ' ';
                                
                                if ($intervention->status_dir == 'approuve') {
                                    $approuve = 'checked';
                                    $button = 'hidden';
                                    $attente = $rejete = $sugg = ' disabled ';
                                } elseif ($intervention->status_dir == 'attente') {
                                    $attente = 'checked';
                                    $approuve = $rejete = ' disabled ';
                                } elseif ($intervention->status_dir == 'rejete') {
                                    $rejete = 'checked';
                                    $approuve = $attente = ' disabled ';
                                }
                            ?>
                            <?php if($intervention->status_dir != null): ?>
                                <div class="col-md-12">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_dir" id="Approuver"
                                            value="approuve" <?php echo e($approuve); ?>>
                                        <label class="form-check-label" for="Approuver">Approuver</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_dir" id="attente"
                                            value="attente" <?php echo e($attente); ?>>
                                        <label class="form-check-label" for="attente">En attente</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_dir" id="rejete"
                                            value="rejete" <?php echo e($rejete); ?>>
                                        <label class="form-check-label" for="rejete">Rejeter</label>
                                    </div>
                                </div>
                                <div class="input-group mb-3">
                                    <span class="input-group-text fw-bold">Avis</span>
                                    <textarea name="suggestion" id="" class="form-control" cols="30" rows="2"
                                        readonly><?php echo e($intervention->commentaire); ?></textarea>
                                </div>
                                <div class="input-group mb-3">
                                    <span class="input-group-text fw-bold">Date</span>
                                    <label
                                        class="form-control"><?php echo e(date('d/m/Y', strtotime($intervention->date_dir))); ?>

                                    </label>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    <h3 class="fw-bold"> La <?php echo e($intervention->dir_demandeur); ?> n'a pas encore
                                        approuvé la fiche d'intervention </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($intervention->status_dir == 'approuve'): ?>


                <div class="col-lg-12">
                    <div class="card  mb-3">
                        <h4 class="card-header text-center">DIN</h4>
                        <div class="card-body">
                            <?php
                                $approuve = $attente = $rejete = $sugg = $button = ' ';
                                
                                if ($intervention->status_din == 'approuve') {
                                    $approuve = 'checked';
                                    $button = 'hidden';
                                    $attente = $rejete = $sugg = ' disabled ';
                                } elseif ($intervention->status_din == 'attente') {
                                    $attente = 'checked';
                                    $approuve = $rejete = ' disabled ';
                                } elseif ($intervention->status_din == 'rejete') {
                                    $rejete = 'checked';
                                    $approuve = $attente = ' disabled ';
                                }
                            ?>
                            <?php if($intervention->status_din != null): ?>
                                <div class="col-md-12">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_din" id="Approuver"
                                            value="approuve" <?php echo e($approuve); ?>>
                                        <label class="form-check-label" for="Approuver">Approuver</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_din" id="attente"
                                            value="attente" <?php echo e($attente); ?>>
                                        <label class="form-check-label" for="attente">En attente</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="status_din" id="rejete"
                                            value="rejete" <?php echo e($rejete); ?>>
                                        <label class="form-check-label" for="rejete">Rejeter</label>
                                    </div>
                                </div>
                                <div class="input-group mb-3">
                                    <span class="input-group-text fw-bold">Avis</span>
                                    <textarea name="suggestion" id="" class="form-control" cols="30" rows="2"
                                        readonly><?php echo e($intervention->avis); ?></textarea>
                                </div>
                                <div class="input-group mb-3">
                                    <span class="input-group-text fw-bold">Date</span>
                                    <label
                                        class="form-control"><?php echo e(date('d/m/Y', strtotime($intervention->date_din))); ?>

                                    </label>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    <h3 class="fw-bold"> Le chef de DIN n'a pas encore
                                        approuvé la fiche d'intervention </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
    <style>
        .card-header {
            background: #4F81BD;
            color: white;
        }

        .ch2 {
            background: #12151A;
            color: white;
        }

        .input-group-text {
            width: 13%;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('2.sih.layout', ['page' => 'Fiche Intervention', 'pageSlug' => 'intervention'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/sih/intervention/show.blade.php ENDPATH**/ ?>