
<?php $__env->startSection('content'); ?>

    <div class="row mt-3">
        <h3 class="fw-bold mt-3">FICHE DE LIVRAISON</h3>
        <div class="row">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('fail')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <form action="addlivraison" role="form" method="post" class="form">
                <?php echo csrf_field(); ?>

                <div class="card col-md-12 mb-3">
                    <h4 class="card-header text-center">Departement</h4>
                    <div class="card-body">
                        <div class="input-group mb-3">
                            <span class="input-group-text txt fw-bold ">Nom de l'intervenant</span>
                            <input type="text" class="form-control" name="nom_intervenant">
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text txt fw-bold ">Direction</span>
                            <select class="form-select" name="direction" id="direction">
                                <option value="" disabled selected>Select Direction</option>
                                <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($direction['sigle']); ?>"><?php echo e($direction['nom']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text txt fw-bold ">Service</span>
                            <select name="service" id="serv" class="form-select"></select>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text txt fw-bold ">Date de livraison</span>
                            <input type="date" class="form-control" name="date_livraison" id="">
                        </div>
                    </div>
                </div>

                <div class="card col-md-12 mb-3">
                    <h4 class="card-header text-center">Materiels</h4>
                    <div class="card-body">
                        <div class="field_wrapper col mb-2">
                            <label class="form-control-label">Participants<span class="text-danger"> *</span></label>
                            <div class="input-group">
                                <a class="input-group-text icon add_button" onclick="addInput()">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </a>
                                <input type="text" class="form-control" name="nom_materiel[]" placeholder="Nom du Materiel" >
                                <input type="text" class="form-control" name="quantite[]" placeholder="Quantité" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')">
                                <input type="text" class="form-control" name="observation[]" placeholder="Observation" >
                                <input type="text" class="form-control" name="id" value="<?php echo e(time()); ?>" hidden>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-5">
                    <div class="col-md-12 form-group">
                        <button type="submit" name="submit" class="btn btn-primary fw-bold">Soumettre</button>
                        <button type="reset" class="btn btn-default fw-bold">Annuler</button>
                        <input type="text" name="date_submit" value="<?php echo e(date('Y-m-d H:i:s')); ?>" hidden>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <style>
        .btn-default:hover {
            background-color: red !important;
            color: white;
        }

        .btn-primary {
            color: white;
        }

        .card-header {
            background: #4F81BD;
            color: white;
        }
        .txt {
            width: 17%;
        }

    </style>
    <script>
        function addInput() {
            $(document).ready(function() {
                var maxField = 10; //Input fields increment limitation
                var addButton = $('.add_button'); //Add button selector
                var wrapper = $('.field_wrapper'); //Input field wrapper
                var fieldHTML =
                    "<div class='input-group'><a class='input-group-text icon remove_button' onclick='removeInput()'><i class='fa fa-minus' aria-hidden='true'></i></a><input type='text' class='form-control' name='nom_materiel[]' placeholder='Nom du Materiel' ><input type='number' class='form-control' name='quantite[]' placeholder='Quantité'  ><input type='text' class='form-control' name='observation[]' placeholder='Observation' ></div>"; //New input field html 
                var x = 1; //Initial field counter is 1

                //Once add button is clicked

                //Check maximum number of input fields
                if (x < maxField) {
                    x++; //Increment field counter
                    $(wrapper).append(fieldHTML); //Add field html
                }


                //Once remove button is clicked
                $(wrapper).on('click', '.remove_button', function(e) {
                    e.preventDefault();
                    $(this).parent('div').remove(); //Remove field html
                    x--; //Decrement field counter
                });
            });
        }
    </script>
    <script>
        $('#direction').change(function() {

            var directionID = $(this).val();

            if (directionID) {

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('getServices')); ?>?dir_id=" + directionID,
                    success: function(res) {

                        if (res) {

                            $("#serv").empty();
                            $("#serv").append('<option>Select Service</option>');
                            $.each(res, function(key, value) {
                                $("#serv").append('<option value="' + value + '">' + value +
                                    '</option>');
                            });

                        } else {

                            $("#serv").empty();
                        }
                    }
                });
            } else {

                $("#serv").empty();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('2.layout', ['page' => 'Nouvelle Livraison', 'pageSlug' => 'livraison'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/livraison/newlivraison.blade.php ENDPATH**/ ?>