
<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="d-flex justify-content-start mb-5">
        <div class="card" style="width: 100%;">
            <div class="card-header d-flex justify-content-between">
                <h3 class="fw-bold">Modif Utilisateur</h3>
                <a href="/admin/showuser" class="btn btn-primary  fw-bold"> <i class="fas fa-arrow-left"></i> RETOURNER</a>
            </div>


            <div class="card-body">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('fail')): ?>
                    <div class="alert alert-danger">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(url('/admin/updateuser', $user)); ?>" role="form" method="post" class="form-card">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row ">
                        <?php
                            $disa = '';
                            if($user->level == '3' || $user->level == '4') {
                                $disa = 'disabled';
                            }
                        ?>

                        <div class="form-group mb-2">
                            <label for="name" class="h4">Level</label>
                            <select name="level" class="form-control" disabled>
                                <option value="1" <?php if($user->level == '1'): ?> <?php echo e('selected'); ?> <?php endif; ?>>1</option>
                                <option value="2" <?php if($user->level == '2'): ?> <?php echo e('selected'); ?> <?php endif; ?>>2</option>
                                <option value="3" <?php if($user->level == '3'): ?> <?php echo e('selected'); ?> <?php endif; ?>>3</option>
                                <option value="4" <?php if($user->level == '4'): ?> <?php echo e('selected'); ?> <?php endif; ?>>4</option>
                            </select>
                            <span class="text-danger"><?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group control-label mb-2">
                            <label class="control-label">Direction </label>
                            <select class="form-select" name="direction" id="direction">
                                <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($direction['sigle'] == old('document') or $direction['sigle'] == $user->direction): ?>
                                        <option value="<?php echo e($direction['sigle']); ?>" selected><?php echo e($direction['nom']); ?>

                                        </option>
                                    <?php else: ?>
                                        <option value="<?php echo e($direction['sigle']); ?>"><?php echo e($direction['nom']); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group control-label mb-2">
                            <label class="control-label">Service </label>
                            <select name="service" id="serv" class="form-select js-select2 " <?php echo e($disa); ?>>
                                <option value="<?php echo e($user->service); ?>" >
                                    <?php echo e($user->service); ?></option>
                            </select>
                            <span class="text-danger"><?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group control-label mb-2">
                            <label class="control-label">Nom </label>
                            <input type="text" class="form-control" name="name" placeholder=" Entrer votre nom "
                                value="<?php echo e($user->name); ?>" required>
                            <span class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group mb-2">
                            <label for="email" class="h5">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Entrer votre email"
                                value="<?php echo e($user->email); ?>">
                            <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="form-group mb-2">
                            <label for="password" class="h5">Password</label>
                            <input type="password" class="form-control" name="password"
                                placeholder="Entrer votre mot de passe" value="<?php echo e($user->password); ?>">
                            <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>


                    </div>


                    <div class="row" style="text-align: center; margin-top: 2%;">
                        <div class=" form-group">
                            <button type="submit" name="submit" class="btn btn-primary fw-bold">Modifier</button>
                            <button type="reset" class="btn btn-default fw-bold">Annuler</button>

                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>

    <style>
        .btn-default:hover {
            background-color: red !important;
            color: white;
        }

    </style>
    <script>
        $('#direction').change(function() {

            var directionID = $(this).val();

            if (directionID) {

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(url('getServices')); ?>?dir_id=" + directionID,
                    success: function(res) {

                        if (res) {

                            $("#serv").empty();
                            $("#serv").append('<option>Select Service</option>');
                            $.each(res, function(key, value) {
                                $("#serv").append('<option value="' + value + '">' + value +
                                    '</option>');
                            });

                        } else {

                            $("#serv").empty();
                        }
                    }
                });
            } else {

                $("#serv").empty();
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('2.sih.layout', ['page' => 'Modif Utilisateu', 'pageSlug' => 'admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/sih/admin/edituser.blade.php ENDPATH**/ ?>