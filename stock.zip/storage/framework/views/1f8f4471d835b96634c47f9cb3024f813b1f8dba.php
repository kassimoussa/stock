<?php
use App\Models\Service;
?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="d-flex justify-content-start mb-5">
        <div class="card" style="width: 100%;">
            <div class="card-header d-flex justify-content-between">
                <h3 class="fw-bold"><?php echo e('Listes des services de la ' . $direction->nom); ?></h3>
                <a href="/admin/showdirections" class="btn btn-primary  fw-bold"> <i class="fas fa-arrow-left"></i>
                    RETOURNER</a>
            </div>


            <div class="card-body ">

                <table class="table  " id="">
                    <thead class=" text-primary">
                        <th scope="col">#</th>
                        <th scope="col">Nom</th>
                    </thead>
                    <tbody>
                        <?php
                            $cnt = 1;
                            $services = Service::where('direction', $direction->sigle)->get();
                        ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($cnt); ?></td>
                                <td><?php echo e($service->nom); ?></td>
                            </tr>
                            <?php
                                $cnt = $cnt + 1;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>

    </div>

    <style>
        .btn-default:hover {
            background-color: red !important;
            color: white;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('2.sih.layout', ['page' => 'Direction', 'pageSlug' => 'admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/2/sih/admin/showdir.blade.php ENDPATH**/ ?>