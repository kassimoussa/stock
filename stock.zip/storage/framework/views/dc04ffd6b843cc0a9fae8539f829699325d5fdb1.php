<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <title>Login</title>

    <style>
        body{
            background: url(bgHome.gif) center center fixed #ffffff no-repeat;
	background-size: cover;
	font-family: "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
	font-weight:300;
	text-align: center;
	text-decoration: none;
	margin: 0 0 0 0;
        }
        .card-header{
            background: white;
        }
        
        .icon{
            width: 7%;
            background-color: #002565;
            color: gold;
        }
        .icon:hover{
            width: 7%;
            background-color: gold;
            color: #002565;
        }
        .btn{
            background-color: #002565;
            color: gold;
        }
        .btn:hover{
            background-color: gold;
            color: #002565;
        }
    </style>
</head>

<body>
    <div class="container" >
        <h1 class="mt-3 fw-bold text-center" style="color: #002565 ">Gestion des Stock</h1>
            <div class=" d-flex justify-content-center align-content-center " style="margin-top: 10%;" >
                <div class="col-sm-6">
                    
                    <?php if($message = Session::get('fail')): ?>
                    <div class="alert alert-danger">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header text-center ">
                        <img src="<?php echo e(asset('dtlogo.png')); ?>" alt="">
                    </div>
                    <div class="card-body">
                       <form action="<?php echo e(route('check')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="input-group mb-2">
                            <span class="input-group-text fw-bold icon"><i class="fas fa-at" ></i></span>
                            <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Taper votre email">
                            <span  class="invalid-feedback"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        <div class="input-group mb-2">
                            <span class="input-group-text fw-bold icon"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" name="password" placeholder="Taper votre mot de passe">
                            <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        
                        <div class="form-group mb-2 d-grid">
                            <button type="submit" class="btn   fw-bold">SE CONNECTER</button>
                        </div>
                        <div class="d-flex justify-content-between">
                         <a href="register" >Ajouter un utilisateur</a>   
                         <a href="forgot" >Mot de passe ouoblié ?</a> 
                        </div>
                        
                    </form> 
                    </div>
                    
                </div>
                    
                </div>
            </div>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\stock\resources\views/auth/login.blade.php ENDPATH**/ ?>