
<?php $__env->startSection('content'); ?>

    <div class="row  py-3 px-3">
        <div class="d-flex justify-content-between mb-2">
            <h3 class="over-title ">Fiches d'intervention  </h3>
        </div>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <?php if($message = Session::get('fail')): ?>
            <div class="alert alert-danger">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div>
            <table class="table tablesorter table-striped " id="">
                <thead class=" text-primary">
                    <th scope="col">N° Fiche</th>
                    <th scope="col">Intervenant</th>
                    <th scope="col">Demandeur</th>
                    <th scope="col">Materiel</th>
                    <th scope="col">Status</th>
                    <th scope="col">Date d'intervention</th>
                    <th scope="col">Action</th>
                </thead>
                <tbody>
                    <?php if(!empty($interventions) && $interventions->count()): ?>
                    <?php
                            $cnt = 1;
                        ?>

                    <?php $__currentLoopData = $interventions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $intervention): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($intervention->id); ?></td>
                            <td><?php echo e($intervention->nom_intervenant); ?></td>
                            <td><?php echo e($intervention->nom_demandeur); ?></td>
                            <td><?php echo e($intervention->materiel); ?></td>
                            <td>
                                <?php
                                    if($intervention->status_direction == null){
                                       
                                    }
                                ?>
                                <p>Direction: <?php echo e($intervention->status_direction); ?></p>
                                <p>SIH: <?php echo e($intervention->status_service); ?></p>
                                <p>DIN: <?php echo e($intervention->status_division); ?></p>
                            </td>
                            <td><?php echo e(date('d/m/Y', strtotime($intervention->date_intervention))); ?></td>
                            <td class="td-actions ">
                                <a href="<?php echo e(url('/intervention/fiche', $intervention)); ?>" class="btn btn-link" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Voir la fiche">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php
                        $cnt = $cnt +1;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10">There are no data.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($interventions->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('4.layout', ['page' => 'Fiches d\'Intervention', 'pageSlug' => 'intervention'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\stock\resources\views/4/intervention/index.blade.php ENDPATH**/ ?>